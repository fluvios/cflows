#include <stdio.h>
#include <string.h>
#include "employee.h"
extern struct Contact PhoneBook[MAX];
extern int size;
void save() {
	printf(" The max and average is written into output.txt");
}

